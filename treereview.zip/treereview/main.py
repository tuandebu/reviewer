import argparse
import json
import os
import traceback

from treereview.agents.answer_synthesizer import AnswerSynthesizer
from treereview.agents.question_generator import QuestionGenerator
from treereview.core import ReviewPipeline, PipelineConfig
from treereview.utility.LLMClient import LLMClient
from treereview.utility.context_ranker import ContextRanker
from treereview.utility.paper_loader import PaperLoader


def parse_arguments():
    parser = argparse.ArgumentParser(description="Run TreeReview pipeline for a single paper.")
    parser.add_argument("--paper-id", type=str, required=True, help="Unique identifier for the paper.")
    parser.add_argument("--mmd-path", type=str, required=True, help="Path to the paper content in MMD format.")
    parser.add_argument("--output-path", type=str, default="review_output.json",
                        help="Path to save the generated review result.")
    parser.add_argument("--state-file", type=str, default=None,
                        help="Checkpoint state file path. Defaults to checkpoint_<paper_id>.json")
    parser.add_argument("--max-depth", type=int, default=4, help="Maximum depth of the question tree.")
    parser.add_argument("--retrieval-top-k", type=int, default=3,
                        help="Number of top chunks to retrieve for context.")
    parser.add_argument("--chunk-size", type=int, default=1024,
                        help="Chunk size used by TextChunker.")
    parser.add_argument("--ranker-model", type=str, default="meta-llama/Llama-3.1-8B-Instruct",
                        help="Hugging Face model used by the context ranker.")
    parser.add_argument("--ranker-device", type=str, default="auto",
                        help="Ranker device: auto, cpu, cuda, cuda:0, mps.")
    parser.add_argument("--with-appendix", action="store_true",
                        help="Include appendix content when building chunks.")
    return parser.parse_args()


def load_config(args) -> PipelineConfig:
    return PipelineConfig(max_depth=args.max_depth, retrieval_top_k=args.retrieval_top_k)


def initialize_agents(args):
    llm = LLMClient()
    question_gen = QuestionGenerator(llm=llm)
    context_ranker = ContextRanker(model_name=args.ranker_model, device_map=args.ranker_device)
    answer_syn = AnswerSynthesizer(llm=llm)
    return question_gen, context_ranker, answer_syn


def load_paper(args):
    paper_loader = PaperLoader(
        paper_id=args.paper_id,
        mmd_path=args.mmd_path,
        with_appendix=args.with_appendix,
        chunk_config={"chunk_size": args.chunk_size},
    )
    return paper_loader.get_paper()


def main():
    args = parse_arguments()
    output_dir = os.path.dirname(args.output_path)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir)

    try:
        print(f"Loading paper with ID: {args.paper_id}")
        paper = load_paper(args)
        print(f"Loaded {len(paper.chunks)} chunks")

        config = load_config(args)
        question_gen, context_ranker, answer_syn = initialize_agents(args)

        print("Initializing review pipeline...")
        pipeline = ReviewPipeline(
            paper=paper,
            question_generator=question_gen,
            context_ranker=context_ranker,
            answer_synthesizer=answer_syn,
            config=config,
            state_file=args.state_file,
        )

        print("Running TreeReview pipeline...")
        result = pipeline.run()

        print(f"Saving results to {args.output_path}")
        with open(args.output_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        print("Review generation completed successfully.")
    except Exception as e:
        print(f"Error during pipeline execution: {e}")
        traceback.print_exc()
        raise SystemExit(1)


if __name__ == "__main__":
    main()
