# TreeReview baseline (Windows-ready package)

This package reorganizes the uploaded TreeReview files into a runnable Python package and applies a few conservative fixes for Windows/local execution:

1. passes `--chunk-size` into `PaperLoader`
2. restores checkpoint stacks by UUID instead of rebuilding disconnected node copies
3. adds package `__init__.py` files
4. adds safer LLM/API error handling
5. adds UTF-8 checkpoint reads/writes for Windows
6. allows ranker model/device to be configured from CLI

## Quick start (Conda)

```powershell
conda create -n treereview python=3.11 -y
conda activate treereview
```

### Install PyTorch

CPU only:

```powershell
pip install torch==2.5.1 torchvision==0.20.1 torchaudio==2.5.1 --index-url https://download.pytorch.org/whl/cpu
```

CUDA 12.1 example:

```powershell
pip install torch==2.5.1 torchvision==0.20.1 torchaudio==2.5.1 --index-url https://download.pytorch.org/whl/cu121
```

Then install the remaining packages:

```powershell
pip install -r requirements.txt
```

## Required environment variables

Gemini API key for generation:

```powershell
setx GEMINI_API_KEY "your_gemini_key_here"
```

Hugging Face token for gated ranker models such as `meta-llama/Llama-3.1-8B-Instruct`:

```powershell
setx HF_TOKEN "your_hf_token_here"
```

After `setx`, open a new terminal.

## Run

Baseline-like run (requires access to the Meta Llama model and is best on GPU):

```powershell
python main.py --paper-id demo1 --mmd-path .\inputs\paper.mmd --output-path .\outputs\review.json --ranker-model meta-llama/Llama-3.1-8B-Instruct --ranker-device cuda --chunk-size 1024
```

CPU smoke test only (not baseline-faithful, but useful to verify the pipeline):

```powershell
python main.py --paper-id demo1 --mmd-path .\inputs\paper.mmd --output-path .\outputs\review.json --ranker-model Qwen/Qwen2.5-0.5B-Instruct --ranker-device cpu --chunk-size 1024
```

## Expected output

The program writes a JSON file with:

- `full_review`
- `feedback_comments`

A checkpoint file is also created unless you set `--state-file` yourself.

## Important notes

- To reproduce the paper more faithfully, keep the original retrieval ranker model and use a GPU.
- If you reuse the same `paper-id`, an old checkpoint may resume automatically.
- The code expects an `.mmd` paper file.
